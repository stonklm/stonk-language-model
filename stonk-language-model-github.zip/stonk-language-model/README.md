# SLM — Stonk Language Model

### The Operating System for AI Agents.

SLM is an open-source runtime for building, running, and orchestrating AI agents.

## What SLM provides

- Agent runtime
- Model adapters
- Memory
- Tools
- Planning
- Task state
- Permissions
- API layer
- Multi-agent foundation

## Quick Start

```bash
git clone https://github.com/YOUR_USERNAME/stonk-language-model.git
cd stonk-language-model

python -m venv .venv
```

### Windows

```powershell
.venv\Scripts\activate
```

### Linux / macOS

```bash
source .venv/bin/activate
```

Install:

```bash
pip install -r requirements.txt
```

Create `.env` from `.env.example` and add your API key.

Run:

```bash
python -m slm
```

## Architecture

```text
                    SLM
        The Operating System
             for AI Agents

                    |
       +------------+------------+
       |            |            |
     Models       Memory       Tools
       |            |            |
       +------------+------------+
                    |
                 Planner
                    |
                 Runtime
                    |
                Security
                    |
                  Agent
```

## Project Structure

```text
src/slm/
├── core/        Agent runtime, tasks, state
├── models/      Model providers
├── memory/      Agent memory
├── tools/       Tool system
├── planning/    Planning engine
├── security/    Permissions
└── api/         API server
```

## Roadmap

- [x] Agent abstraction
- [x] Model abstraction
- [x] Basic memory
- [x] Tool abstraction
- [x] Task/state foundation
- [ ] Persistent memory
- [ ] LLM planning
- [ ] Multi-agent runtime
- [ ] Sandboxed execution
- [ ] Browser agents
- [ ] Agent-to-agent communication
- [ ] Agent marketplace
- [ ] Agent identity
- [ ] Onchain agents
- [ ] SLM Cloud

## Philosophy

Models provide intelligence.

**SLM provides the runtime.**

## License

MIT
