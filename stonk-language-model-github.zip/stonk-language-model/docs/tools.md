# Tools

Tools give agents external capabilities.

Each tool should define:

- Name
- Description
- Input
- Output
- Required permissions

Production tools should validate inputs and should never execute
untrusted commands without sandboxing and explicit permissions.
