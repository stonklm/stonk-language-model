# Roadmap

## v0.1
- Agent
- Model adapter
- Memory
- Tool interface
- Planner foundation
- Permissions foundation
- API foundation

## v0.2
- Persistent memory
- Real tool registry
- LLM planner
- Better state machine

## v0.3
- Multi-agent runtime
- Agent-to-agent messaging
- Background tasks
- Sandboxed code execution

## v0.4
- Browser agents
- Agent identity
- Audit logs
- Resource limits

## v1.0
- Agent marketplace
- Agent packages
- Agent ecosystem
- SLM Cloud
