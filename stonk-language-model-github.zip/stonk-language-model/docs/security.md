# Security

Security is a core part of an agent operating system.

Agents should operate under explicit permissions.

Examples:

- filesystem.read
- filesystem.write
- shell.execute
- network.request
- browser.control
- wallet.read
- wallet.sign

Default policy:

> Deny capabilities unless explicitly granted.

High-risk actions should require confirmation, policy checks,
sandboxing, and audit logging.
