# SLM Architecture

SLM is organized into model, agent, memory, tools, planning, runtime,
API, and security layers.

```text
User
 |
 v
Agent
 |
 +---- Memory
 |
 +---- Planner
 |
 +---- Tools
 |
 +---- Model
 |
 v
Action / Result
 |
 v
State + Memory
```

The long-term goal is to make these components composable so developers
can build different kinds of autonomous agents without rebuilding the
runtime from scratch.
