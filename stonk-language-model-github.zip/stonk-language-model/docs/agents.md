# Agents

An SLM agent is an autonomous software entity that can:

1. Receive an objective
2. Understand the objective
3. Create a plan
4. Select tools
5. Execute actions
6. Observe results
7. Update memory
8. Continue execution
9. Return a final result

Example:

```python
from slm import Agent

agent = Agent(name="researcher")
agent.run("Research AI agent infrastructure.")
```
