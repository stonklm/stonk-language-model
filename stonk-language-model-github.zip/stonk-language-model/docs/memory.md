# Memory

SLM currently provides in-process conversation memory.

Future memory backends may include:

- SQLite
- PostgreSQL
- Vector databases
- Semantic memory
- Long-term agent memory
- Shared multi-agent memory
