# Quickstart

## 1. Clone

```bash
git clone https://github.com/YOUR_USERNAME/stonk-language-model.git
cd stonk-language-model
```

## 2. Create environment

```bash
python -m venv .venv
```

## 3. Activate

Windows:

```powershell
.venv\Scripts\activate
```

Linux/macOS:

```bash
source .venv/bin/activate
```

## 4. Install

```bash
pip install -r requirements.txt
```

## 5. Configure

Copy `.env.example` to `.env` and add your API key.

## 6. Run

```bash
python -m slm
```
