from slm.core.agent import Agent


def test_agent_creation():
    agent = Agent.__new__(Agent)
    agent.name = "test-agent"

    assert agent.name == "test-agent"
