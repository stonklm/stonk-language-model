from slm.tools.base import Tool


class ExampleTool(Tool):
    name = "example"
    description = "Example tool"

    def run(self, **kwargs):
        return "ok"


def test_tool():
    tool = ExampleTool()
    assert tool.run() == "ok"
