from slm.planning.planner import Planner


def test_planner():
    planner = Planner()
    plan = planner.create_plan("test objective")

    assert len(plan) == 4
    assert plan[0]["step"] == 1
