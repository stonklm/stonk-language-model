from slm.memory.memory import Memory


def test_memory_add():
    memory = Memory()

    memory.add("user", "hello")

    assert len(memory.messages()) == 1
    assert memory.messages()[0]["content"] == "hello"


def test_memory_clear():
    memory = Memory()
    memory.add("user", "hello")
    memory.clear()

    assert memory.messages() == []
