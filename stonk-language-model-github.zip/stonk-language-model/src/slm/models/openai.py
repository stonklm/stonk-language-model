import os

from openai import OpenAI

from .base import BaseModel


class OpenAIModel(BaseModel):

    def __init__(self):
        api_key = os.getenv("OPENAI_API_KEY")

        if not api_key:
            raise RuntimeError(
                "OPENAI_API_KEY is missing. Create a .env file from .env.example."
            )

        self.client = OpenAI(api_key=api_key)
        self.model = os.getenv("SLM_MODEL", "gpt-4.1-mini")

    def generate(self, messages: list) -> str:
        response = self.client.chat.completions.create(
            model=self.model,
            messages=messages,
        )

        return response.choices[0].message.content or ""
