from abc import ABC, abstractmethod


class BaseModel(ABC):

    @abstractmethod
    def generate(self, messages: list) -> str:
        raise NotImplementedError
