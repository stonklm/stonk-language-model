from fastapi import FastAPI
from pydantic import BaseModel

from ..core.agent import Agent


app = FastAPI(
    title="SLM",
    description="The Operating System for AI Agents",
    version="0.1.0",
)

agent = Agent(name="api-agent")


class AgentRequest(BaseModel):
    prompt: str


@app.get("/")
def root():
    return {
        "name": "SLM",
        "description": "The Operating System for AI Agents",
        "version": "0.1.0",
    }


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/agent/run")
def run_agent(request: AgentRequest):
    result = agent.run(request.prompt)
    return {"result": result}
