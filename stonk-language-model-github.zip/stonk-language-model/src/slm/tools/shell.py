from .base import Tool


class ShellTool(Tool):
    name = "shell"
    description = "Execute shell commands."

    def run(self, command: str):
        raise PermissionError(
            "Shell execution is disabled by default for security."
        )
