from .base import Tool


class FileSystemTool(Tool):
    name = "filesystem"
    description = "Read and write files inside an approved workspace."

    def run(self, **kwargs):
        raise NotImplementedError(
            "Filesystem access must be connected to an approved sandbox."
        )
