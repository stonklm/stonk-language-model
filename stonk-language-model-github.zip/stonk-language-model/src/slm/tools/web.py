from .base import Tool


class WebSearchTool(Tool):
    name = "web_search"
    description = "Search the web. Provider integration can be added later."

    def run(self, query: str):
        raise NotImplementedError(
            "Connect a search provider before enabling web search."
        )
