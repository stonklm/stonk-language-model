class PermissionManager:

    def __init__(self):
        self.permissions = set()

    def allow(self, permission: str):
        self.permissions.add(permission)

    def deny(self, permission: str):
        self.permissions.discard(permission)

    def check(self, permission: str) -> bool:
        return permission in self.permissions
