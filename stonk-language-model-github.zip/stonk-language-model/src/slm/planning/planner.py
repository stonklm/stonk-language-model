class Planner:

    def create_plan(self, objective: str):
        return [
            {
                "step": 1,
                "task": f"Understand objective: {objective}",
            },
            {
                "step": 2,
                "task": "Determine required tools",
            },
            {
                "step": 3,
                "task": "Execute tasks",
            },
            {
                "step": 4,
                "task": "Verify result",
            },
        ]
