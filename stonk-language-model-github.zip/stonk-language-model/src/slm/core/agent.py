from dataclasses import dataclass, field

from ..memory.memory import Memory
from ..models.openai import OpenAIModel


@dataclass
class Agent:
    name: str
    model: str = "openai"
    memory: Memory = field(default_factory=Memory)

    def __post_init__(self):
        if self.model == "openai":
            self.llm = OpenAIModel()
        else:
            raise ValueError(f"Unsupported model provider: {self.model}")

    def run(self, prompt: str) -> str:
        self.memory.add("user", prompt)

        response = self.llm.generate(self.memory.messages())

        self.memory.add("assistant", response)

        return response
