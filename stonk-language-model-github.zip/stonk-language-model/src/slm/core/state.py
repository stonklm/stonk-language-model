from dataclasses import dataclass, field
from typing import Any


@dataclass
class AgentState:
    status: str = "idle"
    current_task: str | None = None
    step: int = 0
    data: dict[str, Any] = field(default_factory=dict)

    def update(self, key: str, value: Any):
        self.data[key] = value
