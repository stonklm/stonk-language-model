class Memory:

    def __init__(self):
        self._messages = []

    def add(self, role: str, content: str):
        self._messages.append({
            "role": role,
            "content": content,
        })

    def messages(self):
        return list(self._messages)

    def clear(self):
        self._messages.clear()
