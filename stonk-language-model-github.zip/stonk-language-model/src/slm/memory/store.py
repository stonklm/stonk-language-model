class MemoryStore:
    """Placeholder for persistent memory.

    Future versions can implement SQLite, Postgres, vector stores,
    or other persistent memory backends.
    """

    def save(self, agent_id: str, messages: list):
        raise NotImplementedError

    def load(self, agent_id: str) -> list:
        raise NotImplementedError
