from .core.agent import Agent


def main():
    agent = Agent(name="slm-agent")

    print("SLM — The Operating System for AI Agents")
    print("Type 'exit' to quit.\n")

    while True:
        prompt = input("You > ")

        if prompt.lower() == "exit":
            break

        try:
            result = agent.run(prompt)
            print(f"\nSLM > {result}\n")
        except Exception as exc:
            print(f"\nSLM Error > {exc}\n")


if __name__ == "__main__":
    main()
