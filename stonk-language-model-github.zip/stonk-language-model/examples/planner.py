from slm.planning.planner import Planner


planner = Planner()

plan = planner.create_plan(
    "Build an AI research agent"
)

for step in plan:
    print(f"{step['step']}. {step['task']}")
