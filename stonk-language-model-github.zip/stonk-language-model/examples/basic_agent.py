from dotenv import load_dotenv

from slm import Agent


load_dotenv()

agent = Agent(name="researcher")

result = agent.run(
    "Explain what an AI agent is in three sentences."
)

print(result)
